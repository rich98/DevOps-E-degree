import tkinter as tk
import random
import string

def generate_password():
    with open(r'c:\Users\rcwad\OneDrive\Desktop\New folder\word.txt', 'r', encoding='utf-8') as f:
        words = [line.strip() for line in f]
    word1 = random.choice(words).capitalize()
    word2 = random.choice(words).capitalize()
    word3 = random.choice(words).capitalize()
    special_char = random.choice(string.punctuation)
    number = str(random.randint(0, 99)).zfill(2)  # Generate a two-digit number
    password = word1 + word2 + word3 + special_char + number
    result_label.config(text="Generated Password: " + password)

root = tk.Tk()
root.title("Password Generator")

button = tk.Button(root, text="Generate Password", command=generate_password)
button.pack()

result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()


